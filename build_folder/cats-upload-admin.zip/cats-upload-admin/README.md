# cats-upload-admin

# du -sh
# find . -name ".git" | xargs rm -rf
# zip -r cats-upload-admin.zip cats-upload-admin -x *.git*