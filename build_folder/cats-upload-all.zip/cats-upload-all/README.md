# cats-upload-all

cats-upload-all

# du -sh
# find . -name ".git" | xargs rm -rf
# zip -r cats-upload-all.zip cats-upload-all -x *.git*