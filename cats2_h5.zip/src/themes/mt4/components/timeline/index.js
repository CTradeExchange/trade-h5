import timeline from './timeline.vue';
import timelineItem from './timelineItem.vue';
export {
    timeline,
    timelineItem,
}
