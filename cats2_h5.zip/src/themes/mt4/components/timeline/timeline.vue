<template>
    <ul class="timeline">
        <slot></slot>
    </ul>
</template>

<script>
export default {
    setup() {
        return {}
    }
}
</script>

<style lang="scss" scoped>
@import '@/sass/mixin.scss';

</style>
