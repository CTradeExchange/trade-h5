import request from '@/utils/request'

/* 产品基础信息列表 */
export function querySymbolBaseInfoList (data) {
    return request({
        // url: '/global/customer.app.CustomerOptionalWebApiService.querySymbolBaseInfoList',
        url: '/global/rtc.app.RtcSymbolQueryService.querySymbolBaseInfoList',
        method: 'post',
        headers: {
            version: '0.0.1',
        },
        data
    })
}
/* 产品信息 */
export function querySymbolInfo (data) {
    return request({
        url: '/global/rtc.app.RtcSymbolQueryService.querySymbolInfo',
        method: 'post',
        headers: {
            version: '0.0.1',
        },
        data
    })
}

/* 下单 */
export function addMarketOrder (data) {
    return request({
        url: '/global/tradeapi.app.OrderApiService.addMarketOrder',
        method: 'post',
        headers: {
            version: '0.0.1',
            group: 'tradeApi'
        },
        data
    })
}
/* 查看持仓列表 */
export function queryPositionPage (data) {
    return request({
        url: '/global/tradeapi.app.PositionApiService.queryPositionPage',
        method: 'post',
        headers: {
            version: '0.0.1',
            group: 'tradeApi'
        },
        data
    })
}
/* 查看订单列表 */
export function queryOrderPage (data) {
    return request({
        url: '/global/tradeapi.app.OrderApiService.queryOrderPage',
        method: 'post',
        headers: {
            group: 'tradeApi'
        },
        data
    })
}
/* 平仓历史记录列表 */
export function queryHistoryCloseOrderList (data) {
    return request({
        url: '/global/tradeapi.app.OrderApiService.queryHistoryCloseOrderList',
        method: 'post',
        headers: {
            group: 'tradeApi',
            version: '0.0.1',
        },
        data
    })
}
/* 查看预埋单列表 */
export function queryPBOOrderPage (data) {
    return request({
        url: '/global/tradeapi.app.OrderApiService.queryPBOOrderPage',
        method: 'post',
        headers: {
            group: 'tradeApi',
            version: '0.0.1',
        },
        data
    })
}

/* 修改订单 */
export function updateOrder (data) {
    return request({
        url: '/global/tradeapi.app.OrderApiService.updateOrder',
        method: 'post',
        headers: {
            group: 'tradeApi',
            version: '0.0.1',
        },
        data
    })
}

/* 取消预埋单 */
export function closePboOrder (data) {
    return request({
        url: '/global/tradeapi.app.OrderApiService.closePboOrder',
        method: 'post',
        headers: {
            group: 'tradeApi',
            version: '0.0.1',
        },
        data
    })
}

/* 添加自选 */
export function addCustomerOptional (data) {
    return request({
        url: '/global/customer.app.CustomerOptionalWebApiService.add',
        method: 'post',
        headers: {
            // group: 'tradeApi',
            version: '0.0.1',
        },
        data
    })
}
/* 添加自选 */
export function removeCustomerOptional (data) {
    return request({
        url: '/global/customer.app.CustomerOptionalWebApiService.delete',
        method: 'post',
        headers: {
            // group: 'tradeApi',
            version: '0.0.1',
        },
        data
    })
}

/* 根据客户组搜索产品 */
export function getSymbolList (data) {
    return request({
        url: '/global/config.app.AppSymbolDubboService.getSymbolList',
        method: 'post',
        headers: {
            // version: '0.0.1',
        },
        data
    })
}
/* 修改预埋单 */
export function updatePboOrder (data) {
    return request({
        url: '/global/tradeapi.app.OrderApiService.updatePboOrder',
        method: 'post',
        headers: {
            group: 'tradeApi',
            version: '0.0.1',
        },
        data
    })
}
