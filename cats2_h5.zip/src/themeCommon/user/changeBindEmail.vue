<template>
    <bindEmailComponent type='change' />
</template>

<script>
import bindEmailComponent from '@/themeCommon/components/bindEmailComponent'

export default {
    components: {
        bindEmailComponent
    }
}
</script>
