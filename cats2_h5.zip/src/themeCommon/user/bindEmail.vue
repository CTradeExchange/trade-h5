<template>
    <bindEmailComponent type='bind' />
</template>

<script>
import bindEmailComponent from '@/themeCommon/components/bindEmailComponent'

export default {
    components: {
        bindEmailComponent
    }
}
</script>
