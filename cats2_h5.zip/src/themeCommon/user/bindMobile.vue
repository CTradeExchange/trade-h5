<template>
    <bindMobileComponent type='bind' />
</template>

<script>
import bindMobileComponent from '@/themeCommon/components/bindMobileComponent'

export default {
    components: {
        bindMobileComponent
    }
}
</script>
