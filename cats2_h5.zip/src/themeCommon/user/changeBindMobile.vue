<template>
    <bindMobileComponent type='change' />
</template>

<script>
import bindMobileComponent from '@/themeCommon/components/bindMobileComponent'

export default {
    components: {
        bindMobileComponent
    }
}
</script>
