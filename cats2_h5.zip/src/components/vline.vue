<template>
    <span class='vline'>
        |
    </span>
</template>

<script>
export default {
    setup () {
        return {}
    }
}
</script>

<style lang="scss" scoped>
.vline {
    padding: 0 0.5em;
    color: var(--placeholder);
    vertical-align: middle;
}
</style>
