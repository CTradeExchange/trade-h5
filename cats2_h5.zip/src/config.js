export const apiDomain = window.apiService
export const quoteService = window.quoteService
export const msgService = window.msgService
export const tradeService = window.tradeService
